import { useEffect, useLayoutEffect, useRef, useState } from 'react';

/* کلمه همیشه در یک خط؛ اگر جا نشد، اندازهٔ فونت کوچک می‌شود */
function FitWord({ text, maxWidth, base }) {
  const ref = useRef(null);
  const [fontsTick, setFontsTick] = useState(0);
  useEffect(() => { document.fonts?.ready?.then(() => setFontsTick((x) => x + 1)); }, []);
  useLayoutEffect(() => {
    const el = ref.current; if (!el) return;
    el.style.fontSize = base + 'px';
    const w = el.scrollWidth;
    if (w > maxWidth) el.style.fontSize = Math.max(11, Math.floor(base * (maxWidth / w))) + 'px';
  }, [text, maxWidth, base, fontsTick]);
  // فونت فقط از طریق effect تنظیم می‌شود تا رندرهای بعدی آن را برنگردانند
  return <span ref={ref} className="word">{text}</span>;
}
const letters = (w) => { const t = (w || '').replace(/\s+/g, ''); return [t.slice(0, 1), t.slice(-1)]; };
import CATS from './words.json';
import * as sfx from './audio.js';

/* ---------- کمکی‌ها ---------- */
const FA = '۰۱۲۳۴۵۶۷۸۹';
const fa = (n) => String(n).replace(/\d/g, (d) => FA[d]).replace(/,/g, '٬');
const PALETTE = ['#FF5A5F', '#3DDC97', '#4EA8FF', '#FFC857', '#B388FF', '#FF8FC7', '#2EC4B6', '#FF9F43', '#A3E635', '#60E0FF', '#E879F9', '#D6C7A1', '#F87171', '#34D399', '#93C5FD', '#FDE68A'];
const genColor = (i) => `hsl(${Math.round((i * 137.508) % 360)} 80% 64%)`;
const uid = () => Math.random().toString(36).slice(2, 9);
const shuffle = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [a[i], a[j]] = [a[j], a[i]]; } return a; };
const STORE = 'dor-setup-v1';

function pickColor(teams) {
  const used = new Set(teams.map((t) => t.color));
  const free = PALETTE.find((c) => !used.has(c));
  if (free) return free;
  let i = teams.length;
  while (used.has(genColor(i))) i++;
  return genColor(i);
}

const DEFAULT = {
  cats: ['general', 'food', 'animals', 'objects', 'actions'],
  teams: [
    { id: 't1', name: 'تیم یک', color: PALETTE[0], members: ['علی', 'سارا'] },
    { id: 't2', name: 'تیم دو', color: PALETTE[1], members: ['مریم', 'رضا'] },
    { id: 't3', name: 'تیم سه', color: PALETTE[2], members: ['نگار', 'امید'] },
  ],
  teamTime: 120,
  bomb: 30,
  penalty: 1,
  skipCd: 10,
  showFuse: true,
  sound: true,
};

function loadSetup() {
  try {
    const s = JSON.parse(localStorage.getItem(STORE));
    if (s && Array.isArray(s.teams) && s.teams.length >= 2) return { ...DEFAULT, ...s };
  } catch { /* نادیده */ }
  return DEFAULT;
}

/* ---------- موتور بازی ---------- */
function makeGame(setup) {
  const seen = new Set();
  const pool = [];
  CATS.filter((c) => setup.cats.includes(c.id)).forEach((c) => c.words.forEach((w) => { if (!seen.has(w)) { seen.add(w); pool.push(w); } }));
  shuffle(pool);
  const N = setup.teams.length;
  return {
    N,
    teams: setup.teams.map((t) => ({ ...t, time: setup.teamTime, out: false, passUsed: false, hintUsed: false })),
    hint: false,
    cur: 0, rotSteps: 0,
    phase: 'ready', // ready | playing | paused | over
    pool, pi: 0, word: null,
    bomb: setup.bomb, skipCd: 0, tickAcc: 0, tock: false,
    boomAt: 0, msg: 'بزنید تا بازی شروع شود', msgTone: 'info', winner: null, rounds: 0,
  };
}
const nextWord = (g) => { g.hint = false; if (g.pi >= g.pool.length) { shuffle(g.pool); g.pi = 0; } return g.pool[g.pi++]; };
function advance(g) {
  const S = g.N * 2; let k = g.cur, steps = 0;
  do { k = (k + 1) % S; steps++; } while (g.teams[k % g.N].out && steps < S);
  g.cur = k; g.rotSteps += steps;
}
const playerOf = (g, k) => { const t = g.teams[k % g.N]; return { team: t, name: t.members[k < g.N ? 0 : 1] || `بازیکن ${k < g.N ? '۱' : '۲'}` }; };

/* ---------- اپ ---------- */
export default function App() {
  const [setup, setSetup] = useState(loadSetup);
  const [screen, setScreen] = useState('home');
  useEffect(() => { try { localStorage.setItem(STORE, JSON.stringify(setup)); } catch { /* نادیده */ } }, [setup]);
  const upd = (p) => setSetup((s) => ({ ...s, ...p }));

  if (screen === 'game') return <Game setup={setup} onExit={() => setScreen('home')} onSettings={() => setScreen('teams')} />;
  return (
    <div className="shell">
      {screen === 'home' && <Home setup={setup} go={setScreen} />}
      {screen === 'cats' && <Cats setup={setup} upd={upd} go={setScreen} />}
      {screen === 'teams' && <Teams setup={setup} upd={upd} go={setScreen} />}
      {screen === 'settings' && <Settings setup={setup} upd={upd} go={setScreen} />}
    </div>
  );
}

/* ---------- خانه ---------- */
function Home({ setup, go }) {
  const words = CATS.filter((c) => setup.cats.includes(c.id)).reduce((a, c) => a + c.words.length, 0);
  return (
    <div className="home">
      <div className="logo-wrap">
        <MiniRing teams={setup.teams} />
        <h1 className="logo">دور</h1>
      </div>
      <p className="tag">کلمه را به نفرِ روبه‌رویی برسان، قبل از اینکه بمب در دستت بترکد.</p>
      <div className="summary">
        <button className="sum" onClick={() => go('cats')}><b>{fa(setup.cats.length)}</b><span>دسته، {fa(words.toLocaleString('en'))} کلمه</span></button>
        <button className="sum" onClick={() => go('teams')}><b>{fa(setup.teams.length)}</b><span>تیم، {fa(setup.teams.length * 2)} نفر</span></button>
        <button className="sum" onClick={() => go('settings')}><b>{fa(setup.teamTime)}</b><span>ثانیه برای هر تیم</span></button>
      </div>
      <div className="home-actions">
        <button className="btn primary big" onClick={() => go('cats')}>ساختن بازی</button>
        <button className="btn ghost" onClick={() => { sfx.unlock(); go('game'); }}>شروع سریع با همین تنظیمات</button>
      </div>
      <details className="rules">
        <summary>قوانین بازی</summary>
        <ul>
          <li>هر تیم دو نفر است و اعضای تیم روبه‌روی هم دور دایره می‌نشینند.</li>
          <li>کسی که پایین دایره است کلمه را بدون گفتن خودِ کلمه به هم‌تیمی روبه‌رویش می‌رساند.</li>
          <li>وقتی درست حدس زد، روی کلمه بزنید؛ دایره می‌چرخد و نوبت نفر بعدی می‌شود.</li>
          <li>فقط در نوبت هر تیم، زمان همان تیم کم می‌شود. تیمی که زمانش تمام شود حذف است.</li>
          <li>بمب همیشه در حال شمارش است؛ اگر در نوبت تیمی بترکد، از زمان آن تیم کم می‌شود و کلمه عوض می‌شود.</li>
          <li>دکمهٔ «رد» {fa(setup.skipCd)} ثانیه بعد از آمدن هر کلمه فعال می‌شود.</li>
          <li>هر تیم یک بار «عبور» دارد: کلمه رد می‌شود و نوبت به نفر بعدی می‌رسد، انگار درست حدس زده شده.</li>
          <li>هر تیم یک بار «حرف اول و آخر» دارد: توضیح‌دهنده اجازه دارد حرف اول و آخر کلمه را بگوید.</li>
          <li>آخرین تیمی که زمان داشته باشد برنده است.</li>
        </ul>
      </details>
    </div>
  );
}

function MiniRing({ teams }) {
  const N = teams.length, S = N * 2;
  return (
    <svg className="mini-ring" viewBox="-60 -60 120 120" aria-hidden="true">
      <circle r="44" fill="none" stroke="var(--line)" strokeWidth="1.5" strokeDasharray="3 5" />
      {Array.from({ length: S }, (_, k) => {
        const a = (k / S) * Math.PI * 2 + Math.PI / 2;
        return <circle key={k} cx={Math.cos(a) * 44} cy={Math.sin(a) * 44} r={Math.max(4, 11 - S * 0.4)} fill={teams[k % N].color} />;
      })}
    </svg>
  );
}

function StepHead({ title, sub, back, step }) {
  return (
    <header className="step-head">
      <button className="icon-btn" onClick={back} aria-label="بازگشت">→</button>
      <div>
        <div className="eyebrow">مرحلهٔ {fa(step)} از ۳</div>
        <h2>{title}</h2>
        {sub && <p>{sub}</p>}
      </div>
    </header>
  );
}

/* ---------- دسته‌ها ---------- */
function Cats({ setup, upd, go }) {
  const sel = new Set(setup.cats);
  const toggle = (id) => { const n = new Set(sel); n.has(id) ? n.delete(id) : n.add(id); upd({ cats: CATS.map((c) => c.id).filter((x) => n.has(x)) }); };
  const all = sel.size === CATS.length;
  const total = CATS.filter((c) => sel.has(c.id)).reduce((a, c) => a + c.words.length, 0);
  return (
    <div className="page">
      <StepHead step={1} title="کلمه‌ها از چه دسته‌ای باشند؟" sub="هر تعداد دسته که می‌خواهید انتخاب کنید." back={() => go('home')} />
      <div className="cat-tools">
        <span>{fa(sel.size)} دسته انتخاب شده، <b>{fa(total.toLocaleString('en'))}</b> کلمه</span>
        <button className="chip" onClick={() => upd({ cats: all ? [] : CATS.map((c) => c.id) })}>{all ? 'برداشتن همه' : 'انتخاب همه'}</button>
      </div>
      <div className="cat-grid" role="group" aria-label="دسته‌بندی کلمات">
        {CATS.map((c) => (
          <button key={c.id} className={'cat' + (sel.has(c.id) ? ' on' : '')} onClick={() => toggle(c.id)} aria-pressed={sel.has(c.id)}>
            <span className="cat-ic" aria-hidden="true">{c.icon}</span>
            <span className="cat-name">{c.name}</span>
            <span className="cat-sample">{c.words.slice(0, 3).join('، ')}…</span>
            <span className="cat-count">{fa(c.words.length.toLocaleString('en'))} کلمه</span>
            <span className="check" aria-hidden="true">✓</span>
          </button>
        ))}
      </div>
      <footer className="dock">
        <button className="btn primary" disabled={!sel.size} onClick={() => go('teams')}>{sel.size ? 'بعدی: تیم‌ها' : 'حداقل یک دسته انتخاب کنید'}</button>
      </footer>
    </div>
  );
}

/* ---------- تیم‌ها ---------- */
function Teams({ setup, upd, go }) {
  const teams = setup.teams;
  const set = (id, p) => upd({ teams: teams.map((t) => (t.id === id ? { ...t, ...p } : t)) });
  const add = () => upd({ teams: [...teams, { id: uid(), name: `تیم ${fa(teams.length + 1)}`, color: pickColor(teams), members: ['', ''] }] });
  const remove = (id) => teams.length > 2 && upd({ teams: teams.filter((t) => t.id !== id) });
  const cycleColor = (t) => {
    const used = new Set(teams.filter((x) => x.id !== t.id).map((x) => x.color));
    const free = PALETTE.filter((c) => !used.has(c));
    if (!free.length) return;
    const i = free.indexOf(t.color);
    set(t.id, { color: free[(i + 1) % free.length] });
  };
  const listEnd = useRef(null);
  const prevLen = useRef(teams.length);
  useEffect(() => { if (teams.length > prevLen.current) listEnd.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); prevLen.current = teams.length; }, [teams.length]);
  return (
    <div className="page">
      <StepHead step={2} title="تیم‌بندی" sub="هر تیم دو نفر. برای عوض کردن رنگ، روی دایرهٔ رنگی بزنید." back={() => go('cats')} />
      <div className="team-list">
        {teams.map((t, i) => (
          <div key={t.id} className="team-card" style={{ '--tc': t.color }}>
            <div className="team-row">
              <button className="swatch" onClick={() => cycleColor(t)} aria-label="تغییر رنگ تیم" />
              <input id={`tn-${t.id}`} className="team-name" value={t.name} onChange={(e) => set(t.id, { name: e.target.value })} placeholder={`تیم ${fa(i + 1)}`} maxLength={18} />
              <button className="icon-btn danger" onClick={() => remove(t.id)} disabled={teams.length <= 2} aria-label="حذف تیم">✕</button>
            </div>
            <div className="members">
              {[0, 1].map((m) => (
                <label key={m} className="member">
                  <span className="dot" />
                  <input id={`tm-${t.id}-${m}`} value={t.members[m]} maxLength={14}
                    onChange={(e) => { const mm = [...t.members]; mm[m] = e.target.value; set(t.id, { members: mm }); }}
                    placeholder={m ? 'نفر دوم' : 'نفر اول'} />
                </label>
              ))}
              <span className="vs" aria-hidden="true">روبه‌رو</span>
            </div>
          </div>
        ))}
        <button className="add-team" onClick={add} ref={listEnd}>+ افزودن تیم</button>
      </div>
      <footer className="dock">
        <button className="btn primary" onClick={() => go('settings')}>بعدی: زمان‌بندی</button>
      </footer>
    </div>
  );
}

/* ---------- تنظیمات ---------- */
function Stepper({ id, label, hint, value, min, max, step, onChange, unit = 'ثانیه' }) {
  return (
    <div className="stepper">
      <div className="st-label"><label htmlFor={id}>{label}</label>{hint && <small>{hint}</small>}</div>
      <div className="st-ctrl">
        <button className="icon-btn" onClick={() => onChange(Math.min(max, value + step))} aria-label="بیشتر">+</button>
        <output id={id}><b>{fa(value)}</b><small>{unit}</small></output>
        <button className="icon-btn" onClick={() => onChange(Math.max(min, value - step))} aria-label="کمتر">−</button>
      </div>
    </div>
  );
}
function Toggle({ id, label, checked, onChange }) {
  return (
    <label className="toggle" htmlFor={id}>
      <span>{label}</span>
      <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} />
      <i aria-hidden="true" />
    </label>
  );
}
function Settings({ setup, upd, go }) {
  return (
    <div className="page">
      <StepHead step={3} title="زمان‌بندی" sub="همهٔ تیم‌ها با زمان برابر شروع می‌کنند." back={() => go('teams')} />
      <div className="set-list">
        <Stepper id="s-time" label="زمان هر تیم" hint="فقط در نوبت خود تیم کم می‌شود" value={setup.teamTime} min={30} max={600} step={15} onChange={(v) => upd({ teamTime: v })} />
        <Stepper id="s-bomb" label="زمان هر بمب" hint="بعد از هر انفجار دوباره شروع می‌شود" value={setup.bomb} min={10} max={120} step={5} onChange={(v) => upd({ bomb: v })} />
        <Stepper id="s-pen" label="جریمهٔ انفجار" hint="از زمان تیمی که بمب دستش ترکید" value={setup.penalty} min={0} max={30} step={1} onChange={(v) => upd({ penalty: v })} />
        <Stepper id="s-skip" label="فاصلهٔ دکمهٔ رد" hint="بعد از آمدن هر کلمه" value={setup.skipCd} min={0} max={30} step={1} onChange={(v) => upd({ skipCd: v })} />
        <Toggle id="s-fuse" label="نمایش فتیلهٔ بمب دور کلمه" checked={setup.showFuse} onChange={(v) => upd({ showFuse: v })} />
        <Toggle id="s-sound" label="صدای تیک‌تاک و انفجار" checked={setup.sound} onChange={(v) => upd({ sound: v })} />
      </div>
      <footer className="dock">
        <button className="btn primary big" onClick={() => { sfx.unlock(); go('game'); }}>بزن بریم!</button>
      </footer>
    </div>
  );
}

/* ---------- صفحهٔ بازی ---------- */
function Game({ setup, onExit, onSettings }) {
  const gRef = useRef(null);
  if (!gRef.current) gRef.current = makeGame(setup);
  const g = gRef.current;
  const [, setFrame] = useState(0);
  const [menu, setMenu] = useState(false);
  const render = () => setFrame((f) => (f + 1) % 1e9);
  const snd = (fn, ...a) => { if (setup.sound) fn(...a); };

  // اندازهٔ صحنه
  const wrapRef = useRef(null);
  const [S, setS] = useState(320);
  useLayoutEffect(() => {
    const el = wrapRef.current; if (!el) return;
    const ro = new ResizeObserver(([e]) => { const r = e.contentRect; setS(Math.max(220, Math.floor(Math.min(r.width, r.height)))); });
    ro.observe(el); return () => ro.disconnect();
  }, []);

  // جلوگیری از خاموش شدن صفحه
  useEffect(() => {
    let lock = null;
    const req = async () => { try { lock = await navigator.wakeLock?.request('screen'); } catch { /* نادیده */ } };
    req();
    const vis = () => { if (document.visibilityState === 'visible') req(); else if (gRef.current.phase === 'playing') { gRef.current.phase = 'paused'; render(); } };
    document.addEventListener('visibilitychange', vis);
    return () => { document.removeEventListener('visibilitychange', vis); try { lock?.release(); } catch { /* نادیده */ } };
  }, []);

  const eliminate = (g, t) => {
    g.finalTone = false; sfx.stopFinalTone();
    t.time = 0; t.out = true;
    const alive = g.teams.filter((x) => !x.out);
    if (alive.length <= 1) {
      g.phase = 'over'; g.winner = alive[0] || t; snd(sfx.ding);
      return;
    }
    snd(sfx.out);
    g.msg = `زمان «${t.name}» تمام شد و حذف شد`; g.msgTone = 'bad';
    advance(g);
    g.word = nextWord(g); g.bomb = setup.bomb; g.phase = 'ready';
  };

  // حلقهٔ زمان
  useEffect(() => {
    let raf, last = performance.now();
    const loop = (now) => {
      const dt = Math.min(0.1, (now - last) / 1000); last = now;
      const g = gRef.current;
      if (g.phase === 'playing') {
        const t = g.teams[g.cur % g.N];
        t.time -= dt; g.bomb -= dt; g.skipCd = Math.max(0, g.skipCd - dt);
        const frac = Math.max(0, g.bomb / setup.bomb);
        const interval = 0.07 + 0.93 * Math.pow(frac, 1.7);
        g.tickAcc += dt;
        if (g.bomb > 0.55) {
          if (g.tickAcc >= interval) { g.tickAcc = 0; snd(sfx.tick, 1 - frac); }
        } else if (!g.finalTone) { g.finalTone = true; snd(sfx.finalTone, g.bomb); }
        if (t.time <= 0) eliminate(g, t);
        else if (g.bomb <= 0) {
          snd(sfx.boom);
          g.finalTone = false;
          if (navigator.vibrate) try { navigator.vibrate([200, 80, 300]); } catch { /* نادیده */ }
          g.boomAt = now;
          t.time = Math.max(0, t.time - setup.penalty);
          g.bomb = setup.bomb; g.word = nextWord(g);
          g.msg = `بمب در دست «${t.name}» ترکید${setup.penalty ? `؛ ${fa(setup.penalty)} ثانیه جریمه` : ''}`; g.msgTone = 'bad';
          if (t.time <= 0) eliminate(g, t); else g.phase = 'ready';
        }
        render();
      } else if (now - g.boomAt < 1400) render();
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, []);

  const tapCore = () => {
    sfx.unlock();
    if (g.phase === 'ready' || g.phase === 'paused') {
      sfx.stopClips(); sfx.stopFinalTone();
      if (!g.word) g.word = nextWord(g);
      if (g.phase === 'ready') g.skipCd = setup.skipCd;
      g.phase = 'playing'; g.msg = ''; g.tickAcc = 0;
    } else if (g.phase === 'playing') {
      snd(sfx.ding);
      if (navigator.vibrate) try { navigator.vibrate(30); } catch { /* نادیده */ }
      advance(g); g.rounds++;
      g.word = nextWord(g); g.skipCd = setup.skipCd;
    }
    render();
  };
  const skip = () => {
    if (g.phase !== 'playing' || g.skipCd > 0) return;
    snd(sfx.whoosh);
    g.word = nextWord(g); g.skipCd = setup.skipCd; render();
  };
  const curTeam = () => g.teams[g.cur % g.N];
  const usePass = () => {
    const t = curTeam();
    if (g.phase !== 'playing' || t.passUsed) return;
    t.passUsed = true;
    snd(sfx.whoosh);
    advance(g); g.rounds++;
    g.word = nextWord(g); g.skipCd = setup.skipCd;
    render();
  };
  const useHint = () => {
    const t = curTeam();
    if (g.phase !== 'playing' || t.hintUsed || g.hint) return;
    t.hintUsed = true; g.hint = true;
    snd(sfx.ding);
    render();
  };
  const openMenu = () => { if (g.phase === 'playing') g.phase = 'paused'; sfx.stopFinalTone(); setMenu(true); };
  useEffect(() => () => { sfx.stopClips(); sfx.stopFinalTone(); }, []);
  const restart = () => { sfx.stopClips(); gRef.current = makeGame(setup); setMenu(false); render(); };

  // هندسهٔ دایره
  const N = g.N, SEATS = N * 2, step = 360 / SEATS;
  const seat = Math.round(Math.max(34, Math.min(S * 0.17, ((Math.PI * S) / SEATS) * 0.62, 76)));
  const R = S / 2 - seat * 0.62;
  const core = Math.round(Math.min(S * 0.54, 2 * R - seat * 1.55));
  const rot = -g.rotSteps * step;
  const cur = playerOf(g, g.cur);
  const partnerK = (g.cur + N) % SEATS;
  const partner = playerOf(g, partnerK);
  const frac = Math.max(0, g.bomb / setup.bomb);
  const booming = performance.now() - g.boomAt < 1400 && g.boomAt > 0;
  const circ = 2 * Math.PI * (core / 2 + 7);
  const wordSize = Math.round(core * 0.15);
  const [firstL, lastL] = letters(g.word);
  const ct = g.teams[g.cur % N];
  const maxTime = Math.max(setup.teamTime, ...g.teams.map((t) => t.time));

  return (
    <div className={'game' + (booming ? ' shake-all' : '')} style={{ '--cur': cur.team.color }}>
      <header className="g-top">
        <div className="tubes" role="list" aria-label="زمان تیم‌ها">
          {g.teams.map((t, i) => {
            const pct = Math.max(0, (t.time / maxTime) * 100);
            const active = i === g.cur % N && g.phase !== 'over';
            return (
              <div key={t.id} role="listitem" className={'tube' + (active ? ' on' : '') + (t.out ? ' out' : '') + (t.time < 15 && !t.out ? ' low' : '')} style={{ '--tc': t.color }}>
                <div className="glass">
                  <div className="liquid" style={{ height: pct + '%' }}>
                    <svg className="wave" viewBox="0 0 120 12" preserveAspectRatio="none" aria-hidden="true"><path d="M0 6 Q15 0 30 6 T60 6 T90 6 T120 6 V12 H0Z" /></svg>
                  </div>
                </div>
                <div className="tube-num">{t.out ? '✕' : fa(Math.ceil(t.time))}</div>
                <div className="tube-name">{t.name}</div>
                <div className="powers-dots" aria-label="فرصت‌های باقی">
                  <i className={t.passUsed ? 'used' : ''} title="عبور" />
                  <i className={t.hintUsed ? 'used' : ''} title="حرف اول و آخر" />
                </div>
              </div>
            );
          })}
        </div>
        <button className="icon-btn menu-btn" onClick={openMenu} aria-label="توقف بازی و منو" style={{ letterSpacing: 0 }}>
          <svg viewBox="0 0 24 24" width="24" height="24" aria-hidden="true" style={{ display: 'block' }}>
            <path d="M3 5.5v13a1 1 0 0 0 1.5.86l10.2-6.5a1 1 0 0 0 0-1.72L4.5 4.64A1 1 0 0 0 3 5.5z" fill="currentColor" />
            <rect x="16" y="5" width="2.4" height="14" rx="1.2" fill="currentColor" />
            <rect x="20" y="5" width="2.4" height="14" rx="1.2" fill="currentColor" />
          </svg>
        </button>
      </header>

      <main className="arena-wrap" ref={wrapRef}>
        <div className="arena" style={{ width: S, height: S }}>
          <div className="axis" style={{ height: 2 * R }} />
          <div className="ring" style={{ transform: `rotate(${rot}deg)`, width: 2 * R, height: 2 * R }} />
          {Array.from({ length: SEATS }, (_, k) => {
            const p = playerOf(g, k);
            const isCur = k === g.cur && g.phase !== 'over';
            const isPartner = k === partnerK && g.phase !== 'over';
            const a = k * step + rot;
            return (
              <div key={k} className={'seat' + (isCur ? ' cur' : '') + (isPartner ? ' partner' : '') + (p.team.out ? ' out' : '')}
                style={{ '--tc': p.team.color, width: seat, height: seat, transform: `translate(-50%,-50%) rotate(${a}deg) translateY(${R}px) rotate(${-a}deg)` }}>
                <div className="bubble" style={{ fontSize: seat * 0.36 }}>{p.name.slice(0, 1)}</div>
                <div className="seat-name">{p.name}</div>
              </div>
            );
          })}

          <button className={'core ' + g.phase + (g.phase === 'playing' && frac < 0.25 ? ' urgent' : '')} style={{ width: core, height: core }} onClick={tapCore}>
            {setup.showFuse && (
              <svg className="fuse" viewBox={`0 0 ${core + 20} ${core + 20}`} style={{ width: core + 20, height: core + 20 }} aria-hidden="true">
                <circle cx={core / 2 + 10} cy={core / 2 + 10} r={core / 2 + 7} className="fuse-bg" />
                <circle cx={core / 2 + 10} cy={core / 2 + 10} r={core / 2 + 7} className="fuse-fg"
                  style={{ strokeDasharray: circ, strokeDashoffset: circ * (1 - frac), stroke: frac < 0.25 ? 'var(--hot)' : 'var(--fuse)' }} />
              </svg>
            )}
            {g.phase === 'playing' && (
              <span className="word-box">
                <FitWord text={g.word} maxWidth={core * 0.86} base={wordSize} />
                {g.hint ? (
                  <span className="letters" aria-label="حرف اول و آخر">
                    <span><small>اول</small><b>{firstL}</b></span>
                    <span><small>آخر</small><b>{lastL}</b></span>
                  </span>
                ) : (
                  <span className="core-hint">درست گفت؟ بزن</span>
                )}
              </span>
            )}
            {(g.phase === 'ready' || g.phase === 'paused') && (
              <span className="word-box">
                <span className="start">{g.phase === 'paused' ? 'ادامه' : 'شروع'}</span>
                <span className="core-hint">{cur.name} شروع می‌کند</span>
              </span>
            )}
            {g.phase === 'over' && <span className="word-box"><span className="start">تمام</span></span>}
          </button>
          <Bomb frac={frac} playing={g.phase === 'playing'} size={Math.max(26, core * 0.2)} offset={core / 2 + 4} />
        </div>
      </main>

      <footer className="g-bottom">
        <div className="turn">
          {g.msg ? (
            <div className={'msg ' + g.msgTone}>{g.msg}</div>
          ) : (
            <div className="who">
              <span className="pill" style={{ '--tc': cur.team.color }}>{cur.name}</span>
              <span className="arrow">توضیح می‌دهد به</span>
              <span className="pill ghost" style={{ '--tc': partner.team.color }}>{partner.name}</span>
            </div>
          )}
        </div>
        <div className="act-row">
          <div className="powers" style={{ '--tc': ct.color }}>
              <button className={'power' + (ct.passUsed ? ' used' : '')} onClick={usePass}
                disabled={g.phase !== 'playing' || ct.passUsed}>
                <span className="p-ic" aria-hidden="true">⇥</span>
                <span className="p-tx"><b>عبور</b><small>{ct.passUsed ? 'استفاده شد' : 'یک بار'}</small></span>
              </button>
              <button className={'power' + (ct.hintUsed ? ' used' : '')} onClick={useHint}
                disabled={g.phase !== 'playing' || ct.hintUsed}>
                <span className="p-ic" aria-hidden="true">آ‌ی</span>
                <span className="p-tx"><b>اول و آخر</b><small>{ct.hintUsed ? 'استفاده شد' : 'یک بار'}</small></span>
              </button>
            </div>
        <button className={'skip' + (g.phase === 'playing' && g.skipCd <= 0 ? ' ready' : '')} onClick={skip}
          disabled={g.phase !== 'playing' || g.skipCd > 0}
          style={{ '--p': g.phase === 'playing' ? 1 - g.skipCd / Math.max(1, setup.skipCd) : 0 }} aria-label="کلمهٔ بعدی">
          <span>{g.phase === 'playing' && g.skipCd > 0 ? fa(Math.ceil(g.skipCd)) : 'رد'}</span>
        </button>
        </div>
      </footer>

      {booming && <div className="boom" aria-live="assertive"><span>بوم!</span></div>}

      {menu && (
        <div className="sheet-bg" onClick={() => setMenu(false)}>
          <div className="sheet" onClick={(e) => e.stopPropagation()}>
            <h3>بازی متوقف شد</h3>
            <button className="btn primary" onClick={() => setMenu(false)}>برگشت به بازی</button>
            <button className="btn ghost" onClick={restart}>شروع دوباره</button>
            <button className="btn ghost" onClick={onSettings}>تغییر تیم‌ها و تنظیمات</button>
            <button className="btn ghost" onClick={onExit}>خروج به خانه</button>
          </div>
        </div>
      )}

      {g.phase === 'over' && g.winner && (
        <div className="sheet-bg win">
          <div className="sheet" style={{ '--tc': g.winner.color }}>
            <div className="crown" aria-hidden="true">
              <svg viewBox="0 0 64 40"><path d="M4 36 L8 8 L22 22 L32 2 L42 22 L56 8 L60 36 Z" fill="var(--tc)" /></svg>
            </div>
            <div className="eyebrow">برندهٔ دور</div>
            <h3 className="win-name">{g.winner.name}</h3>
            <p>{g.winner.members.filter(Boolean).join(' و ')}، {fa(Math.ceil(g.winner.time))} ثانیه باقی ماند</p>
            <button className="btn primary" onClick={restart}>یک دور دیگر</button>
            <button className="btn ghost" onClick={onSettings}>تغییر تیم‌ها</button>
            <button className="btn ghost" onClick={onExit}>خانه</button>
          </div>
        </div>
      )}
    </div>
  );
}

function Bomb({ frac, playing, size, offset }) {
  const hot = frac < 0.25;
  return (
    <div className={'bomb' + (playing ? ' live' : '') + (hot && playing ? ' hot' : '')}
      style={{ width: size, height: size, transform: `translate(calc(-50% - ${offset * 0.72}px), calc(-50% - ${offset * 0.72}px))`, '--spd': `${0.15 + frac * 0.9}s` }} aria-hidden="true">
      <svg viewBox="0 0 40 40">
        <circle cx="18" cy="23" r="14" fill="#2b2838" stroke="#0c0a12" strokeWidth="1.5" />
        <circle cx="13" cy="18" r="4" fill="#fff" opacity=".18" />
        <rect x="22" y="6" width="8" height="7" rx="1.5" transform="rotate(35 26 9)" fill="#4a4560" />
        <path d="M29 6 q4 -4 7 -1" stroke="#c9a46a" strokeWidth="2" fill="none" />
        <circle className="spark" cx="36" cy="5" r="3.2" fill="var(--fuse)" />
      </svg>
    </div>
  );
}