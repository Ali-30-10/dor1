import boomUrl from './sounds/boom.mp3';
import memeUrl from './sounds/pashmam.mp3';
let ctx = null;
export function unlock() {
  try {
    if (!ctx) {
      const AC = window.AudioContext || window.webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') ctx.resume();
    preload();
  } catch { return null; }
  return ctx;
}
function env(g, t, peak, dur) {
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(peak, t + 0.004);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
}
// شمارش معکوس بمب مثل فیلم‌ها: یک بیپ تمیز و تیز که فاصله‌اش کم‌کم کوتاه‌تر،
// زیرش کمی بالاتر و صدایش بلندتر می‌شود؛ به‌همراه ضربان بم ملایم برای هیجان.
export function tick(urgency) {
  const c = unlock(); if (!c) return;
  const t = c.currentTime;
  const u = Math.min(1, Math.max(0, urgency));
  const freq = 1750 + u * 450;               // کمی زیرتر شدن
  const dur = 0.085 - u * 0.045;             // بیپ کوتاه‌تر در انتها
  const vol = 0.18 + u * 0.22;
  const out = c.createGain(); out.gain.value = vol;
  const bp = c.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = freq; bp.Q.value = 2.5;
  out.connect(c.destination);
  // بدنهٔ بیپ: سینوسی + مربعی فیلترشده برای حالت «الکترونیکی»
  [['sine', 1], ['square', 0.35]].forEach(([type, amp]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(amp, t + 0.004);
    g.gain.setValueAtTime(amp, t + dur * 0.7);
    g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    if (type === 'square') o.connect(g).connect(bp).connect(out);
    else o.connect(g).connect(out);
    o.start(t); o.stop(t + dur + 0.02);
  });
  // ضربان بم (مثل صدای قلب) که با نزدیک شدن به انفجار پررنگ‌تر می‌شود
  const k = c.createOscillator(), kg = c.createGain();
  k.type = 'sine';
  k.frequency.setValueAtTime(95, t);
  k.frequency.exponentialRampToValueAtTime(45, t + 0.12);
  kg.gain.setValueAtTime(0.0001, t);
  kg.gain.exponentialRampToValueAtTime(0.12 + u * 0.4, t + 0.006);
  kg.gain.exponentialRampToValueAtTime(0.0001, t + 0.14);
  k.connect(kg).connect(c.destination); k.start(t); k.stop(t + 0.16);
}

// لحظه‌های آخر: بیپ‌ها به یک صدای ممتد که زیرتر می‌شود تبدیل می‌شوند
let finalNodes = null;
export function finalTone(seconds) {
  const c = unlock(); if (!c) return;
  stopFinalTone();
  const t = c.currentTime, d = Math.max(0.15, seconds);
  const o = c.createOscillator(), g = c.createGain();
  o.type = 'sine';
  o.frequency.setValueAtTime(2200, t);
  o.frequency.exponentialRampToValueAtTime(3000, t + d);
  g.gain.setValueAtTime(0.0001, t);
  g.gain.exponentialRampToValueAtTime(0.35, t + 0.03);
  g.gain.setValueAtTime(0.35, t + d - 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, t + d + 0.02);
  o.connect(g).connect(c.destination); o.start(t); o.stop(t + d + 0.05);
  finalNodes = { o, g };
}
export function stopFinalTone() {
  if (!finalNodes) return;
  try { finalNodes.o.stop(); } catch { /* نادیده */ }
  finalNodes = null;
}

function noiseBuf(c, len) {
  const buf = c.createBuffer(1, Math.floor(c.sampleRate * len), c.sampleRate);
  const d = buf.getChannelData(0);
  for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
  return buf;
}

// انفجار موشک: سوت کوتاه موشک، ترق انفجار، غرش بم و ریزش آوار
function synthBoom() {
  const c = unlock(); if (!c) return;
  const t0 = c.currentTime;
  const master = c.createDynamicsCompressor();
  master.threshold.value = -18; master.ratio.value = 8;
  const mg = c.createGain(); mg.gain.value = 1.2;
  master.connect(mg).connect(c.destination);

  // ۱) سوت موشک
  const w = c.createOscillator(), wg = c.createGain();
  w.type = 'sine';
  w.frequency.setValueAtTime(2600, t0);
  w.frequency.exponentialRampToValueAtTime(500, t0 + 0.35);
  wg.gain.setValueAtTime(0.0001, t0);
  wg.gain.exponentialRampToValueAtTime(0.25, t0 + 0.05);
  wg.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.36);
  w.connect(wg).connect(master); w.start(t0); w.stop(t0 + 0.4);

  const t = t0 + 0.34; // لحظهٔ انفجار

  // ۲) ترق تیز
  const cr = c.createBufferSource(); cr.buffer = noiseBuf(c, 0.12);
  const hp = c.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 1200;
  const cg = c.createGain();
  cg.gain.setValueAtTime(1.6, t); cg.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
  cr.connect(hp).connect(cg).connect(master); cr.start(t);

  // ۳) غرش اصلی
  const len = 3;
  const bn = c.createBufferSource(); bn.buffer = noiseBuf(c, len);
  const lp = c.createBiquadFilter(); lp.type = 'lowpass'; lp.Q.value = 1.5;
  lp.frequency.setValueAtTime(4000, t);
  lp.frequency.exponentialRampToValueAtTime(300, t + 0.4);
  lp.frequency.exponentialRampToValueAtTime(50, t + len);
  const dist = c.createWaveShaper();
  const curve = new Float32Array(1024);
  for (let i = 0; i < 1024; i++) { const x = (i / 512) - 1; curve[i] = Math.tanh(x * 3); }
  dist.curve = curve;
  const bg = c.createGain();
  bg.gain.setValueAtTime(0.0001, t);
  bg.gain.exponentialRampToValueAtTime(2.2, t + 0.01);
  bg.gain.exponentialRampToValueAtTime(0.6, t + 0.6);
  bg.gain.exponentialRampToValueAtTime(0.001, t + len);
  bn.connect(lp).connect(dist).connect(bg).connect(master); bn.start(t);

  // ۴) ضربهٔ بم زیر
  const sub = c.createOscillator(), sg = c.createGain();
  sub.type = 'sine';
  sub.frequency.setValueAtTime(160, t);
  sub.frequency.exponentialRampToValueAtTime(30, t + 1.2);
  sg.gain.setValueAtTime(0.0001, t);
  sg.gain.exponentialRampToValueAtTime(1.4, t + 0.01);
  sg.gain.exponentialRampToValueAtTime(0.001, t + 1.4);
  sub.connect(sg).connect(master); sub.start(t); sub.stop(t + 1.5);

  // ۵) ریزش آوار
  for (let i = 0; i < 26; i++) {
    const at = t + 0.25 + Math.random() * 1.6;
    const d = c.createBufferSource(); d.buffer = noiseBuf(c, 0.05);
    const bp = c.createBiquadFilter(); bp.type = 'bandpass';
    bp.frequency.value = 800 + Math.random() * 3000; bp.Q.value = 4;
    const dg = c.createGain();
    dg.gain.setValueAtTime(0.0001, at);
    dg.gain.exponentialRampToValueAtTime(0.25 + Math.random() * 0.35, at + 0.004);
    dg.gain.exponentialRampToValueAtTime(0.0001, at + 0.05);
    d.connect(bp).connect(dg).connect(master); d.start(at);
  }
}

// صداهای فایل ویدیو، از قبل بارگذاری و رمزگشایی می‌شوند تا بدون تاخیر پخش شوند.
// ترتیب: انفجار ویدیو، و بلافاصله بعدش کل صدای ویدیو تا وقتی کاربر «شروع» بزند.
const buffers = {};
let loading = null;
async function loadBuf(c, url) {
  const res = await fetch(url);
  const arr = await res.arrayBuffer();
  return await new Promise((ok, bad) => c.decodeAudioData(arr, ok, bad));
}
export function preload() {
  const c = ctx; if (!c || loading) return loading;
  loading = Promise.all([
    loadBuf(c, boomUrl).then((b) => { buffers.boom = b; }).catch(() => {}),
    loadBuf(c, memeUrl).then((b) => { buffers.meme = b; }).catch(() => {}),
  ]);
  return loading;
}
let playing = [];
function playBuf(buf, when, vol = 1) {
  const c = ctx;
  const src = c.createBufferSource(); src.buffer = buf;
  const g = c.createGain(); g.gain.value = vol;
  src.connect(g).connect(c.destination);
  src.start(when);
  playing.push(src);
  src.onended = () => { playing = playing.filter((x) => x !== src); };
  return src;
}
// انفجار + صدای کامل ویدیو، پشت‌سرهم و بدون فاصله
export function boom(withMeme = true) {
  const c = unlock(); if (!c) return;
  stopFinalTone();
  stopClips();
  const t = c.currentTime + 0.005;
  if (buffers.boom) {
    playBuf(buffers.boom, t, 1);
    if (withMeme && buffers.meme) playBuf(buffers.meme, t + buffers.boom.duration - 0.05, 1);
  } else {
    synthBoom();
    if (withMeme && buffers.meme) playBuf(buffers.meme, t + 1.2, 1);
    else if (withMeme) speakMeme();
  }
}
export function meme() { /* از این پس داخل boom پخش می‌شود */ }
export function stopClips() {
  playing.forEach((s) => { try { s.stop(); } catch { /* نادیده */ } });
  playing = [];
}
function speakMeme() {
  try {
    const synth = window.speechSynthesis; if (!synth) return;
    const voice = synth.getVoices().find((v) => /^fa/i.test(v.lang));
    if (!voice) return;
    const u = new SpeechSynthesisUtterance('پشمام! پشمام!');
    u.voice = voice; u.lang = voice.lang; u.rate = 1.15; u.pitch = 1.3;
    synth.cancel(); synth.speak(u);
  } catch { /* نادیده */ }
}

export function ding() {
  const c = unlock(); if (!c) return;
  const t = c.currentTime;
  [[880, 0], [1320, 0.07]].forEach(([fr, dl]) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = 'triangle'; o.frequency.value = fr;
    env(g, t + dl, 0.25, 0.25);
    o.connect(g).connect(c.destination); o.start(t + dl); o.stop(t + dl + 0.3);
  });
}
export function whoosh() {
  const c = unlock(); if (!c) return;
  const t = c.currentTime;
  const o = c.createOscillator(), g = c.createGain();
  o.type = 'sine'; o.frequency.setValueAtTime(300, t); o.frequency.exponentialRampToValueAtTime(700, t + 0.15);
  env(g, t, 0.12, 0.18);
  o.connect(g).connect(c.destination); o.start(t); o.stop(t + 0.2);
}
export function out() {
  const c = unlock(); if (!c) return;
  const t = c.currentTime;
  [0, 0.22, 0.44].forEach((dl, i) => {
    const o = c.createOscillator(), g = c.createGain();
    o.type = 'sawtooth'; o.frequency.value = 260 - i * 50;
    env(g, t + dl, 0.18, 0.2);
    o.connect(g).connect(c.destination); o.start(t + dl); o.stop(t + dl + 0.22);
  });
}